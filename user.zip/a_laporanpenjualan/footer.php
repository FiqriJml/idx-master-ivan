<div class="footer">
    <div class="pull-right">
        <b>Copyright 2019 ©</b> Rumah Kreatif BUMN 
    </div>
</div>