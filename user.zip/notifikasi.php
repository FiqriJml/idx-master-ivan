<?php
    $hitung = mysqli_query($con, "select * from laporan_bulanan");

    $num = mysqli_num_rows($hitung);
?>

